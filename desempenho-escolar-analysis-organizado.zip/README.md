# 📊 Análise de Desempenho Escolar

Este projeto utiliza Python, Pandas e Streamlit para analisar dados de desempenho escolar e gerar insights visuais interativos.

## Como rodar localmente
```bash
pip install -r requirements.txt
streamlit run app/main.py
```

## App Online
[🔗 Acesse o App no Streamlit Cloud](https://desempenho-escolar-analysis.streamlit.app)
